#!/usr/bin/env bash
set -e
echo "🚀 Checking for ExamShield updates via APT..."
sudo apt update
sudo apt install --only-upgrade examshield -y
echo "✅ Update check complete."
