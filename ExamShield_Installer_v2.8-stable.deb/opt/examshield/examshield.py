#!/usr/bin/env python3
"""
ExamShield v2.7 — Enterprise Exam Security Daemon
------------------------------------------------------------
Features:
✅ Network Whitelisting (IPTables Kill-switch)
✅ Heartbeat Monitoring (Anti-Tamper)
✅ Screenshot Evidence on Violation
✅ Secure Config Storage (Permission Hardening)
✅ Async Telegram Core (v20+)
------------------------------------------------------------
"""

import os, sys, json, time, threading, socket, logging, signal, psutil, asyncio, subprocess, atexit
from datetime import datetime

# Dependency check
try:
    import pyudev
    import mss
    from telegram import Bot, Update
    from telegram.ext import Application, CommandHandler, ContextTypes
    from telegram.constants import ParseMode
except ImportError:
    print("Missing dependencies. Run: sudo pip3 install pyudev python-telegram-bot psutil mss")
    sys.exit(1)

# ----------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------
VERSION = "2.7"
CONFIG_FILE = '/etc/examshield/config.json'
CHAT_LIST_FILE = '/etc/examshield/chatlist.json'
LOG_DIR = '/var/log/examshield'
USB_LOG = os.path.join(LOG_DIR, 'usb.log')
HOSTNAME = socket.gethostname()

# Network Settings
TELEGRAM_API_DOMAIN = "api.telegram.org"

BROWSERS = [
    '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable',
    '/usr/bin/chromium', '/usr/bin/chromium-browser',
    '/usr/bin/firefox', '/usr/bin/brave-browser', '/usr/bin/microsoft-edge'
]
DESKTOP_FILES = [
    '/usr/share/applications/google-chrome.desktop',
    '/usr/share/applications/chromium.desktop',
    '/usr/share/applications/firefox.desktop',
    '/usr/share/applications/brave-browser.desktop',
    '/usr/share/applications/microsoft-edge.desktop'
]

# Setup Logging
os.makedirs(LOG_DIR, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    filename=os.path.join(LOG_DIR, 'examshield.log'),
    format='%(asctime)s %(levelname)s: %(message)s'
)
logging.getLogger('').addHandler(logging.StreamHandler())

# ----------------------------------------------------------------
# Utilities
# ----------------------------------------------------------------
def now_str():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

class Config:
    def __init__(self, path=CONFIG_FILE):
        self.data = {}
        if os.path.exists(path):
            # SECURITY: Enforce 600 permissions (Root Read/Write ONLY)
            try:
                current_mode = os.stat(path).st_mode & 0o777
                if current_mode != 0o600:
                    os.chmod(path, 0o600)
                    logging.info("Secured config file permissions to 600.")
            except Exception: pass
            
            try:
                with open(path) as f: self.data = json.load(f)
            except Exception: logging.exception('Failed to read config')

    @property
    def token(self): return self.data.get('bot_token')
    @property
    def chat_id(self): return self.data.get('chat_id')

cfg = Config()

def load_chatlist():
    if os.path.exists(CHAT_LIST_FILE):
        try:
            with open(CHAT_LIST_FILE) as f: return json.load(f)
        except: return []
    return []

def save_chatlist(chats):
    os.makedirs(os.path.dirname(CHAT_LIST_FILE), exist_ok=True)
    with open(CHAT_LIST_FILE, "w") as f: json.dump(list(set(chats)), f, indent=2)

# ----------------------------------------------------------------
# Evidence Collection (Screenshots)
# ----------------------------------------------------------------
def take_screenshot(filename_prefix="violation"):
    """Captures screenshot using MSS."""
    if 'DISPLAY' not in os.environ:
        os.environ['DISPLAY'] = ':0'
        
    fpath = os.path.join(LOG_DIR, f"{filename_prefix}_{int(time.time())}.png")
    try:
        with mss.mss() as sct:
            sct.shot(mon=1, output=fpath)
        return fpath
    except Exception as e:
        logging.error(f"Screenshot failed: {e}")
        return None

# ----------------------------------------------------------------
# Async Alert System
# ----------------------------------------------------------------
async def send_async_alert(event, details, photo_path=None):
    if not cfg.token: return
    
    chats = load_chatlist()
    if not chats and cfg.chat_id: chats = [cfg.chat_id]
    
    msg = (
        f"🛡 *ExamShield Enterprise v{VERSION}*\n"
        f"🖥 *Host:* {HOSTNAME}\n"
        f"🕒 *Time:* {now_str()}\n"
        f"🚨 *Event:* {event}\n"
        f"📝 *Details:* {details}"
    )
    
    bot = Bot(token=cfg.token)
    for chat in chats:
        try:
            if photo_path and os.path.exists(photo_path):
                await bot.send_photo(chat_id=chat, photo=open(photo_path, 'rb'), caption=msg, parse_mode=ParseMode.MARKDOWN)
            else:
                await bot.send_message(chat_id=chat, text=msg, parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            logging.warning(f"Failed to send alert to {chat}: {e}")

def trigger_alert_sync(event, details, capture_screen=False):
    """Wrapper to call async code from synchronous threads."""
    photo = None
    if capture_screen:
        photo = take_screenshot()
    
    try:
        asyncio.run(send_async_alert(event, details, photo))
    except Exception as e:
        logging.error(f"Failed to trigger sync alert: {e}")

# ----------------------------------------------------------------
# Network Firewall Controller (IPTables)
# ----------------------------------------------------------------
class NetworkFirewall:
    def __init__(self):
        self.locked = False
        self.unlock_network() # Safety reset on init

    def get_telegram_ip(self):
        try: return socket.gethostbyname(TELEGRAM_API_DOMAIN)
        except: return None

    def lock_network(self):
        """Drops all traffic except DNS and Telegram."""
        if self.locked: return
        
        tg_ip = self.get_telegram_ip()
        logging.info(f"Locking network. Whitelisting Telegram IP: {tg_ip}")

        cmds = [
            "iptables -F OUTPUT", 
            "iptables -P OUTPUT DROP", 
            "iptables -A OUTPUT -o lo -j ACCEPT", 
            "iptables -A OUTPUT -p udp --dport 53 -j ACCEPT", 
            "iptables -A OUTPUT -p tcp --dport 53 -j ACCEPT"
        ]
        
        if tg_ip: cmds.append(f"iptables -A OUTPUT -d {tg_ip} -j ACCEPT")
        # Add your exam portal IP here if needed:
        # cmds.append(f"iptables -A OUTPUT -d 192.168.1.100 -j ACCEPT")

        for cmd in cmds: os.system(cmd)
            
        self.locked = True
        return True

    def unlock_network(self):
        os.system("iptables -P OUTPUT ACCEPT")
        os.system("iptables -F OUTPUT")
        self.locked = False

net_ctrl = NetworkFirewall()

# ----------------------------------------------------------------
# Exam Logic Controller
# ----------------------------------------------------------------
class ExamModeController:
    def __init__(self):
        self.in_exam = False
        self._saved_execs = {}
        self._restore_browsers() 

    def _kill_browsers(self):
        count = 0
        for p in psutil.process_iter(['pid', 'name', 'exe']):
            try:
                exe = (p.info['exe'] or '').lower()
                if any(b in exe for b in ('chrome', 'firefox', 'brave', 'edge', 'chromium')):
                    p.kill()
                    count += 1
            except: pass
        return count

    def _disable_browsers(self):
        self._saved_execs = {}
        for path in BROWSERS:
            if os.path.exists(path):
                try:
                    st = os.stat(path)
                    self._saved_execs[path] = st.st_mode
                    os.chmod(path, st.st_mode & ~0o111)
                except: pass
        for d in DESKTOP_FILES:
            if os.path.exists(d):
                try: os.rename(d, d + '.disabled')
                except: pass

    def _restore_browsers(self):
        for path in BROWSERS:
            if os.path.exists(path):
                try: os.chmod(path, 0o755)
                except: pass
        for d in DESKTOP_FILES:
            if os.path.exists(d + '.disabled'):
                try: os.rename(d + '.disabled', d)
                except: pass

    def enter_exam(self):
        if self.in_exam: return False
        killed = self._kill_browsers()
        self._disable_browsers()
        net_ctrl.lock_network()
        self.in_exam = True
        trigger_alert_sync("Exam Mode ENABLED", f"Firewall Active.\nBrowsers Killed: {killed}.\nUSB Blocked.")
        return True

    def exit_exam(self):
        if not self.in_exam: return False
        net_ctrl.unlock_network()
        self._restore_browsers()
        self.in_exam = False
        os.system("for d in /sys/bus/usb/devices/*; do echo 1 > $d/authorized 2>/dev/null; done")
        trigger_alert_sync("Exam Mode DISABLED", "System and Network restored to normal.")
        return True

exam_ctrl = ExamModeController()

# ----------------------------------------------------------------
# Threads: Heartbeat & USB
# ----------------------------------------------------------------
class HeartbeatMonitor(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.interval = 60 
    def run(self):
        logging.info("Heartbeat active.")
        while True:
            time.sleep(self.interval)
            if exam_ctrl.in_exam:
                try: asyncio.run(send_async_alert("💓 Heartbeat", "System Secure. Monitoring Active.", photo_path=None))
                except: pass

class USBMonitor(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.context = pyudev.Context()
        self.monitor = pyudev.Monitor.from_netlink(self.context)
        self.monitor.filter_by('usb')
    def run(self):
        logging.info("USB monitor active.")
        for device in iter(self.monitor.poll, None):
            try:
                action = device.action
                if action not in ('add', 'remove'): continue
                msg = f"{device.get('ID_VENDOR','?')} {device.get('ID_MODEL','?')} ({device.get('ID_SERIAL_SHORT','?')})"
                
                if exam_ctrl.in_exam and action == 'add':
                    trigger_alert_sync("USB VIOLATION", f"Blocked device: {msg}", capture_screen=True)
                    os.system("for d in /sys/bus/usb/devices/*; do echo 0 > $d/authorized 2>/dev/null; done")
                    os.system("sudo beep -f 900 -l 250 || echo -e '\\a'")
                else:
                    trigger_alert_sync(f"USB {action.upper()}", msg, capture_screen=False)
            except Exception: logging.exception("USB error")

# ----------------------------------------------------------------
# Async Command Handlers
# ----------------------------------------------------------------
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cid = update.effective_chat.id
    chats = load_chatlist()
    if cid not in chats:
        chats.append(cid); save_chatlist(chats)
    await update.message.reply_text(f"✅ Registered ExamShield Enterprise on {HOSTNAME}.")

async def cmd_exam(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ok = exam_ctrl.enter_exam()
    await update.message.reply_text(f"🛡 Exam Mode: {'Active' if ok else 'Already Active'}")

async def cmd_normal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ok = exam_ctrl.exit_exam()
    await update.message.reply_text(f"✅ Normal Mode: {'Restored' if ok else 'Was Normal'}")

async def cmd_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        with open(USB_LOG, 'r') as f: lines = f.readlines()[-10:]
        text = f"🧾 *Last 10 Logs ({HOSTNAME}):*\n```\n" + ''.join(lines) + "\n```"
    except: text = "No logs available."
    await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

# ----------------------------------------------------------------
# Main
# ----------------------------------------------------------------
def cleanup():
    net_ctrl.unlock_network()
    exam_ctrl._restore_browsers()

def main():
    atexit.register(cleanup)
    USBMonitor().start()
    HeartbeatMonitor().start()

    if not cfg.token:
        logging.error("No token found in config."); return

    app = Application.builder().token(cfg.token).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("exam", cmd_exam))
    app.add_handler(CommandHandler("normal", cmd_normal))
    app.add_handler(CommandHandler("logs", cmd_logs))

    logging.info("System Online.")
    trigger_alert_sync("System Online", "ExamShield Enterprise Daemon started.")
    app.run_polling()

if __name__ == "__main__": main()