#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox
import json, os, subprocess, requests, time
from PIL import Image, ImageTk

CFG="/etc/examshield/config.json"; LOGO="/opt/examshield/logo.png"
VER_FILE="/etc/examshield/version"; THIS_VERSION="2.7"

def splash():
    s=tk.Tk(); s.overrideredirect(True); s.configure(bg="#0b3d91")
    w,h=520,300; sw,sh=s.winfo_screenwidth(),s.winfo_screenheight()
    s.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")
    if os.path.exists(LOGO):
        try: img=Image.open(LOGO).resize((150,150)); ph=ImageTk.PhotoImage(img)
        except: ph=None
        if ph: tk.Label(s,image=ph,bg="#0b3d91").pack(pady=(30,10)); s.photo=ph
    tk.Label(s,text="ExamShield",font=("Helvetica",22,"bold"),fg="white",bg="#0b3d91").pack()
    tk.Label(s,text="Enterprise Edition",font=("Helvetica",12),fg="#FFD700",bg="#0b3d91").pack()
    s.after(2500,s.destroy); s.mainloop()

def main_gui():
    root=tk.Tk(); root.title(f"ExamShield v{THIS_VERSION} Setup")
    root.geometry("760x380"); root.configure(bg="#f5f6fa")
    main=ttk.Frame(root,padding=12); main.pack(fill="both",expand=True)
    
    tk.Label(main,text="ExamShield Enterprise Setup",font=("Helvetica",16,"bold")).pack(pady=10)
    tk.Label(main,text="Telegram BOT TOKEN:",font=("Helvetica",10)).pack(anchor="w")
    e1=ttk.Entry(main,width=60); e1.pack(pady=5)
    tk.Label(main,text="Telegram CHAT ID:",font=("Helvetica",10)).pack(anchor="w")
    e2=ttk.Entry(main,width=60); e2.pack(pady=5)
    status=tk.Label(main,text="",fg="#333"); status.pack(pady=10)
    bar=ttk.Progressbar(main,mode="indeterminate",length=380); bar.pack(pady=5)

    def upd(t): status.config(text=t); status.update_idletasks()
    def run(cmd): return subprocess.run(cmd,shell=True)
    def test_bot(tk,chat):
        try: return requests.post(f"https://api.telegram.org/bot{tk}/sendMessage",data={"chat_id":chat,"text":"✅ Setup OK"},timeout=5).status_code==200
        except: return False

    def install():
        t=e1.get().strip(); c=e2.get().strip()
        if not t or not c: messagebox.showerror("Error","Missing fields"); return
        
        os.system("sudo mkdir -p /etc/examshield")
        with open(CFG,"w") as f: json.dump({"bot_token":t,"chat_id":c},f)
        os.chmod(CFG, 0o600)
        with open(VER_FILE,"w") as f: f.write(THIS_VERSION)

        bar.start(10); upd("Fixing package locks & dependencies...")
        
        # --- AUTO-FIX: RELEASE LOCKS ---
        os.system("sudo fuser -vk /var/lib/dpkg/lock >/dev/null 2>&1 || true")
        os.system("sudo rm -f /var/lib/dpkg/lock >/dev/null 2>&1 || true")
        os.system("sudo rm -f /var/lib/dpkg/lock-frontend >/dev/null 2>&1 || true")
        os.system("sudo rm -f /var/cache/apt/archives/lock >/dev/null 2>&1 || true")
        os.system("sudo dpkg --configure -a >/dev/null 2>&1 || true")
        # -------------------------------
        
        run("sudo apt update -y && sudo apt install -y python3-pip python3-tk python3-psutil iptables")
        run("sudo -H pip3 install --no-cache-dir pyudev python-telegram-bot psutil mss pillow requests")

        svc="[Unit]\nDescription=ExamShield\nAfter=network.target\n[Service]\nUser=root\nEnvironment=DISPLAY=:0\nExecStart=/usr/bin/python3 /opt/examshield/examshield.py\nRestart=always\n[Install]\nWantedBy=multi-user.target"
        os.system(f"echo '{svc}' | sudo tee /etc/systemd/system/examshield.service > /dev/null")
        run("sudo systemctl daemon-reload && sudo systemctl enable --now examshield.service")
        
        if test_bot(t,c): messagebox.showinfo("Success","✅ Installed & Connected!"); root.destroy()
        else: messagebox.showwarning("Warning","Installed, but Telegram connection failed.")

    ttk.Button(main,text="Install",command=install).pack(pady=20)
    root.mainloop()

if __name__=="__main__": splash(); main_gui()
