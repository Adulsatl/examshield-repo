#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox
import json, os, subprocess, sys

CFG="/etc/examshield/config.json"
LIC="/etc/examshield/license.key"
PROD_ID="Jq1p0Sw3o7xP0UGGTy38WQ=="
LOGO_PATH="/opt/examshield/logo.png"
VENV_PATH="/opt/examshield/venv"

def install():
    t=e1.get().strip()
    c=e2.get().strip()
    k=e3.get().strip()
    
    if not t or not c or not k: 
        messagebox.showerror("Error","Missing Fields")
        return
    
    # 1. Verify License
    print(f"Verifying Key...")
    try:
        cmd = [
            "curl", "-s", "-X", "POST", "https://api.gumroad.com/v2/licenses/verify",
            "-H", "User-Agent: Mozilla/5.0",
            "-d", f"product_id={PROD_ID}", "-d", f"license_key={k}", "-d", "increment_uses_count=false"
        ]
        result = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
        if not result: raise Exception("Empty response")
        d = json.loads(result)
        if not d.get("success") or d.get("purchase",{}).get("refunded"):
            messagebox.showerror("Failed", "Invalid License Key"); return
    except Exception as e:
        messagebox.showerror("Error", f"Verification Error: {e}"); return

    # 2. Save Credentials
    os.system("sudo mkdir -p /etc/examshield")
    with open(CFG,"w") as f: json.dump({"bot_token":t,"chat_id":c},f)
    os.chmod(CFG, 0o600)
    with open(LIC,"w") as f: f.write(k)
    
    # 3. Create Virtual Environment
    print("Creating Isolated Environment...")
    try:
        subprocess.run("sudo apt-get install -y python3-venv", shell=True)
        
        if not os.path.exists(VENV_PATH):
            subprocess.run([sys.executable, "-m", "venv", VENV_PATH], check=True)
        
        pip_cmd = f"{VENV_PATH}/bin/pip"
        subprocess.run([pip_cmd, "install", "--upgrade", "pip"], check=True)
        subprocess.run([pip_cmd, "install", "python-telegram-bot==20.6", "pyudev", "mss", "psutil", "requests"], check=True)
        
    except Exception as e:
        messagebox.showerror("Error", f"Dependency Install Failed: {e}"); return

    # 4. Create Service
    print("Configuring Service...")
    svc=f"""[Unit]
Description=ExamShield
After=graphical.target
[Service]
User=root
Environment=DISPLAY=:0
ExecStart={VENV_PATH}/bin/python3 /opt/examshield/examshield.py
Restart=always
[Install]
WantedBy=multi-user.target
"""
    with open("/tmp/examshield.service", "w") as f: f.write(svc)
    os.system("sudo mv /tmp/examshield.service /etc/systemd/system/examshield.service")
    
    # 5. Start
    try:
        subprocess.run("sudo systemctl daemon-reload", shell=True)
        subprocess.run("sudo systemctl enable examshield.service", shell=True)
        subprocess.Popen(["sudo", "systemctl", "restart", "examshield.service"])
        msg = "Success! ExamShield is starting in the background."
    except Exception as e:
        msg = f"Installed, but auto-start failed: {e}"

    messagebox.showinfo("Installation Complete", msg)
    root.quit()

root=tk.Tk(); root.title("ExamShield Setup"); root.geometry("500x450")

if os.path.exists(LOGO_PATH):
    try:
        logo_img = tk.PhotoImage(file=LOGO_PATH)
        ttk.Label(root, image=logo_img).pack(pady=10)
    except: pass

ttk.Label(root,text="Bot Token:").pack(pady=5); e1=ttk.Entry(root,width=50); e1.pack()
ttk.Label(root,text="Chat ID:").pack(pady=5); e2=ttk.Entry(root,width=50); e2.pack()
ttk.Label(root,text="License Key:").pack(pady=5); e3=ttk.Entry(root,width=50); e3.pack()
ttk.Button(root,text="Install & Start",command=install).pack(pady=20)
ttk.Label(root, text="Developed by Aduls", font=("Arial", 9, "italic")).pack(side="bottom", pady=10)

root.mainloop()
