#!/usr/bin/env python3
"""
ExamShield v4.2 — Enterprise Exam Security System
Integrated with Gumroad Licensing (Annual/Month/Lifetime)
Fixed for Python 3.8+ Asyncio Compatibility
"""
import os, sys, json, time, threading, socket, logging, psutil, asyncio, subprocess, atexit, requests, hashlib
from datetime import datetime, timedelta

# --- CONFIGURATION ---
VERSION = "4.2"

# ⚠️ GUMROAD CONFIGURATION ⚠️
GUMROAD_PRODUCT_ID = "Jq1p0Sw3o7xP0UGGTy38WQ==" 

# File Paths
CONFIG_FILE = '/etc/examshield/config.json'
LICENSE_FILE = '/etc/examshield/license.key'
CACHE_FILE = '/etc/examshield/.license_cache'
STATE_FILE = '/etc/examshield/state.json'
LOG_DIR = '/var/log/examshield'
HOSTNAME = socket.gethostname()
TELEGRAM_API_DOMAIN = "api.telegram.org"
TRUSTED_DNS = "8.8.8.8"

# Blacklists
BROWSERS = [
    '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable',
    '/usr/bin/chromium', '/usr/bin/chromium-browser',
    '/usr/bin/firefox', '/usr/bin/brave-browser', '/usr/bin/microsoft-edge'
]

# Dependency Check
try:
    import pyudev, mss
    from telegram import Bot
    from telegram.ext import Application, CommandHandler
except ImportError:
    print("CRITICAL: Missing dependencies. Dependencies will be installed by the setup script.")
    sys.exit(1)

# Logging
try:
    os.makedirs(LOG_DIR, exist_ok=True)
    logging.basicConfig(level=logging.INFO, filename=os.path.join(LOG_DIR, 'examshield.log'), format='%(asctime)s %(levelname)s: %(message)s')
except PermissionError:
    print(f"ERROR: Permission denied for {LOG_DIR}. Please run with sudo.")
    sys.exit(1)

# --- PERSISTENCE ---
def save_state(active: bool):
    try:
        with open(STATE_FILE, 'w') as f: json.dump({"active": active}, f)
    except: pass

def load_state():
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, 'r') as f: return json.load(f).get("active", False)
    except: pass
    return False

def cache_license(key):
    try:
        h = hashlib.sha256(f"{key}-{HOSTNAME}-valid".encode()).hexdigest()
        with open(CACHE_FILE, 'w') as f: json.dump({"valid": True, "hash": h, "date": time.time()}, f)
        os.chmod(CACHE_FILE, 0o600)
    except: pass

def check_cached_license(key):
    try:
        if not os.path.exists(CACHE_FILE): return False
        with open(CACHE_FILE, 'r') as f: data = json.load(f)
        h = hashlib.sha256(f"{key}-{HOSTNAME}-valid".encode()).hexdigest()
        if data.get("hash") == h and (time.time() - data.get("date", 0) < 86400):
            logging.info("License verified via Local Cache")
            return True
    except: pass
    return False

# --- LICENSE LOGIC ---
def validate_license():
    try:
        if not os.path.exists(LICENSE_FILE): 
            print("License file missing.")
            return False
            
        with open(LICENSE_FILE, 'r') as f: key = f.read().strip()
        
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
                "Content-Type": "application/x-www-form-urlencoded"
            }
            
            r = requests.post("https://api.gumroad.com/v2/licenses/verify", 
                              data={"product_id": GUMROAD_PRODUCT_ID, "license_key": key}, 
                              headers=headers,
                              timeout=10)
            
            data = r.json()
            
            if data.get("success") and not data.get("purchase", {}).get("refunded", False):
                purchase = data.get("purchase", {})
                if purchase.get("subscription_cancelled_at") or purchase.get("subscription_failed_at"):
                    logging.critical("Subscription Cancelled or Failed")
                    return False

                variant = purchase.get("variants", "").lower()
                if "lifetime" in variant:
                    cache_license(key); return True

                created = purchase.get("created_at", "")
                if created:
                    dt_purchase = datetime.fromisoformat(created.replace('Z', '+00:00'))
                    dt_now = datetime.now(dt_purchase.tzinfo)
                    days_active = (dt_now - dt_purchase).days
                    
                    if "annual" in variant or "year" in variant:
                        if days_active > 366: logging.critical("Annual License Expired"); return False
                    elif "month" in variant:
                        if days_active > 32: logging.critical("Monthly License Expired"); return False
                
                cache_license(key)
                return True

        except requests.exceptions.RequestException:
            logging.warning("Offline Mode: Checking Cache...")
            return check_cached_license(key)
            
    except Exception as e: logging.error(f"Lic Err: {e}")
    return False

# --- CORE CLASSES ---
class Config:
    def __init__(self):
        self.data = {}
        try:
            if (os.stat(CONFIG_FILE).st_mode & 0o777) != 0o600: os.chmod(CONFIG_FILE, 0o600)
            with open(CONFIG_FILE) as f: self.data = json.load(f)
        except: pass
    @property
    def token(self): return self.data.get('bot_token')
    @property
    def chat_id(self): return self.data.get('chat_id')
cfg = Config()

async def send_alert(msg, photo=None):
    if not cfg.token: return
    bot = Bot(token=cfg.token)
    try:
        if photo: await bot.send_photo(cfg.chat_id, photo=open(photo, 'rb'), caption=msg)
        else: await bot.send_message(cfg.chat_id, text=msg)
    except: pass

def trigger_sync(msg, capture=False):
    """
    Sends an alert.
    Safe for use in Threads (USBWatch).
    DO NOT call this from the Main Thread after the bot has started.
    """
    photo = None
    if capture:
        path = f"{LOG_DIR}/ev_{int(time.time())}.png"
        try:
            with mss.mss() as sct: sct.shot(mon=1, output=path); photo = path
        except:
            try: subprocess.run(["gnome-screenshot", "-f", path], timeout=2); photo = path if os.path.exists(path) else None
            except: pass
            
    try:
        # Create a new event loop only for this thread
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(send_alert(f"🛡 {HOSTNAME}: {msg}", photo))
        loop.close()
    except Exception as e:
        logging.error(f"Sync failed: {e}")

class Firewall:
    def lock(self):
        try: ip = socket.gethostbyname(TELEGRAM_API_DOMAIN)
        except: ip = None
        cmds = [
            "iptables -F OUTPUT", "iptables -P OUTPUT DROP",
            "iptables -A OUTPUT -o lo -j ACCEPT",
            f"iptables -A OUTPUT -p udp -d {TRUSTED_DNS} --dport 53 -j ACCEPT",
            f"iptables -A OUTPUT -p tcp -d {TRUSTED_DNS} --dport 53 -j ACCEPT"
        ]
        if ip: cmds.append(f"iptables -A OUTPUT -d {ip} -j ACCEPT")
        for c in cmds: os.system(c)
    def unlock(self):
        os.system("iptables -P OUTPUT ACCEPT; iptables -F OUTPUT")

class ExamCtrl:
    def __init__(self): self.active = False
    
    def _kill_browsers(self):
        for p in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                if any(x in (p.info['name'] or '').lower() for x in ('chrome', 'firefox', 'brave', 'edge')):
                    p.kill()
            except: pass

    def enter(self):
        if self.active: return False
        save_state(True)
        self._kill_browsers()
        Firewall().lock()
        self.active = True
        trigger_sync("🚨 EXAM LOCKED.")
        return True

    def exit(self):
        if not self.active: return False
        save_state(False)
        Firewall().unlock()
        self.active = False
        trigger_sync("✅ EXAM UNLOCKED.")
        return True

ctrl = ExamCtrl()

class USBWatch(threading.Thread):
    def __init__(self): super().__init__(daemon=True); self.mon = pyudev.Monitor.from_netlink(pyudev.Context()); self.mon.filter_by('usb')
    def run(self):
        for d in iter(self.mon.poll, None):
            if d.action == 'add' and ctrl.active:
                trigger_sync(f"VIOLATION: USB {d.get('ID_MODEL','Device')}", capture=True)
                os.system("for d in /sys/bus/usb/devices/*; do echo 0 > $d/authorized 2>/dev/null; done")

class Heartbeat(threading.Thread):
    def __init__(self): super().__init__(daemon=True)
    def run(self):
        while True:
            time.sleep(60)
            if ctrl.active: 
                ctrl._kill_browsers()
                try: 
                    # Use specialized sync for heartbeat thread
                    trigger_sync("💓 Monitoring Active")
                except: pass

async def start(u, c): await u.message.reply_text(f"Connected to {HOSTNAME}")
async def exam(u, c): await u.message.reply_text(f"Exam: {'Active' if ctrl.enter() else 'On'}")
async def normal(u, c): await u.message.reply_text(f"Normal: {'Restored' if ctrl.exit() else 'Off'}")

async def post_init(application: Application):
    """
    Called when the bot starts up. Replaces the main thread trigger_sync 
    to prevent Event Loop conflicts.
    """
    await send_alert(f"🛡 {HOSTNAME}: System Online")

def main():
    if not validate_license():
        print("FATAL: License Invalid or Expired.")
        sys.exit(1)
    
    atexit.register(lambda: (Firewall().unlock(), ctrl.exit()))
    USBWatch().start(); Heartbeat().start()
    
    if load_state():
        logging.warning("Recovered from crash/reboot. Re-locking system.")
        ctrl.enter()

    # FIX: Use post_init to send startup message safely
    app = Application.builder().token(cfg.token).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("exam", exam))
    app.add_handler(CommandHandler("normal", normal))
    
    print("System Online. Waiting for commands...")
    # This takes control of the event loop
    app.run_polling()

if __name__ == "__main__": main()