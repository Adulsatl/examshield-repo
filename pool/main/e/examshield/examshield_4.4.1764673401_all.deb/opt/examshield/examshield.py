#!/usr/bin/env python3
"""
ExamShield v4.6 — Enterprise Exam Security System
Integrated with Gumroad Licensing
Fixes: Asyncio Event Loop Crash & Permission Handling
"""
import os, sys, json, time, threading, socket, logging, psutil, asyncio, subprocess, atexit, requests, hashlib
from datetime import datetime

# --- CONFIGURATION ---
VERSION = "4.6"
GUMROAD_PRODUCT_ID = "Jq1p0Sw3o7xP0UGGTy38WQ==" 

# File Paths
CONFIG_FILE = '/etc/examshield/config.json'
LICENSE_FILE = '/etc/examshield/license.key'
CACHE_FILE = '/etc/examshield/.license_cache'
STATE_FILE = '/etc/examshield/state.json'
LOG_DIR = '/var/log/examshield'
HOSTNAME = socket.gethostname()
TELEGRAM_API_DOMAIN = "api.telegram.org"
TRUSTED_DNS = "8.8.8.8"

# Root Check
if os.geteuid() != 0:
    print("❌ FATAL: ExamShield MUST run as root (sudo).")
    sys.exit(1)

# Logging
try:
    os.makedirs(LOG_DIR, exist_ok=True)
    logging.basicConfig(level=logging.INFO, filename=os.path.join(LOG_DIR, 'examshield.log'), format='%(asctime)s %(levelname)s: %(message)s')
except Exception as e:
    print(f"Logger Error: {e}")

# Dependency Check
try:
    import pyudev, mss
    from telegram import Bot
    from telegram.ext import Application, CommandHandler
except ImportError:
    print("CRITICAL: Missing dependencies. Dependencies will be installed by the setup script.")
    sys.exit(1)

# --- UTILS ---
def get_license_snippet():
    try:
        if os.path.exists(LICENSE_FILE):
            with open(LICENSE_FILE, 'r') as f: return f.read().strip()[:8].upper()
    except: pass
    return "UNKNOWN"

def get_formatted_message(status_msg):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lic = get_license_snippet()
    return (f"🖥  <b>Host:</b> {HOSTNAME}\n"
            f"⏰ <b>Time:</b> {now}\n"
            f"🆔 <b>Serial:</b> {lic}\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"🔔 <b>STATUS:</b> {status_msg}")

# --- PERSISTENCE ---
def save_state(active: bool):
    try:
        with open(STATE_FILE, 'w') as f: json.dump({"active": active}, f)
    except: pass

def load_state():
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, 'r') as f: return json.load(f).get("active", False)
    except: pass
    return False

def cache_license(key):
    try:
        h = hashlib.sha256(f"{key}-{HOSTNAME}-valid".encode()).hexdigest()
        with open(CACHE_FILE, 'w') as f: json.dump({"valid": True, "hash": h, "date": time.time()}, f)
        os.chmod(CACHE_FILE, 0o600)
    except: pass

def check_cached_license(key):
    try:
        if not os.path.exists(CACHE_FILE): return False
        with open(CACHE_FILE, 'r') as f: data = json.load(f)
        h = hashlib.sha256(f"{key}-{HOSTNAME}-valid".encode()).hexdigest()
        if data.get("hash") == h and (time.time() - data.get("date", 0) < 86400):
            return True
    except: pass
    return False

# --- LICENSE LOGIC ---
def validate_license():
    try:
        if not os.path.exists(LICENSE_FILE): return False
        with open(LICENSE_FILE, 'r') as f: key = f.read().strip()
        
        try:
            headers = {"User-Agent": "Mozilla/5.0", "Content-Type": "application/x-www-form-urlencoded"}
            r = requests.post("https://api.gumroad.com/v2/licenses/verify", 
                              data={"product_id": GUMROAD_PRODUCT_ID, "license_key": key}, 
                              headers=headers, timeout=10)
            data = r.json()
            if data.get("success") and not data.get("purchase", {}).get("refunded", False):
                cache_license(key)
                return True
        except:
            return check_cached_license(key)
    except: pass
    return False

# --- CORE CLASSES ---
class Config:
    def __init__(self):
        self.data = {}
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE) as f: self.data = json.load(f)
        except: pass
    @property
    def token(self): return self.data.get('bot_token')
    @property
    def chat_id(self): return self.data.get('chat_id')
cfg = Config()

async def send_alert(msg, photo=None):
    if not cfg.token: return
    try:
        # We assume 'bot' is managed by the Application context usually, 
        # but for standalone triggers we create a temporary instance.
        # This is inefficient but thread-safe for USBWatch.
        async with Bot(token=cfg.token) as bot:
            text_body = get_formatted_message(msg)
            if photo: 
                await bot.send_photo(cfg.chat_id, photo=open(photo, 'rb'), caption=text_body, parse_mode='HTML')
            else: 
                await bot.send_message(cfg.chat_id, text=text_body, parse_mode='HTML')
    except Exception as e:
        logging.error(f"Telegram Error: {e}")

def trigger_sync(msg, capture=False):
    """
    Robust alert trigger that handles both Threaded and Async contexts.
    Fixes the 'RuntimeError: This event loop is already running' crash.
    """
    photo = None
    if capture:
        path = f"{LOG_DIR}/ev_{int(time.time())}.png"
        try:
            # Fallback screenshot logic
            try:
                env = os.environ.copy(); env['DISPLAY'] = ':0'
                subprocess.run(["gnome-screenshot", "-f", path], env=env, timeout=2)
                if os.path.exists(path): photo = path
            except:
                with mss.mss() as sct: sct.shot(mon=1, output=path); photo = path
        except: pass

    try:
        # 🟢 CRITICAL FIX: Check if we are already in an Event Loop
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # If called from /exam (Main Thread), use the existing loop
            loop.create_task(send_alert(msg, photo))
        else:
            # If called from USBWatch (Background Thread), create a new loop
            new_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(new_loop)
            new_loop.run_until_complete(send_alert(msg, photo))
            new_loop.close()
            
    except Exception as e:
        logging.error(f"Sync failed: {e}")

class Firewall:
    def lock(self):
        try: ip = socket.gethostbyname(TELEGRAM_API_DOMAIN)
        except: ip = None
        os.system("iptables -F OUTPUT")
        os.system("iptables -P OUTPUT DROP")
        os.system("iptables -A OUTPUT -o lo -j ACCEPT")
        os.system(f"iptables -A OUTPUT -p udp -d {TRUSTED_DNS} --dport 53 -j ACCEPT")
        os.system(f"iptables -A OUTPUT -p tcp -d {TRUSTED_DNS} --dport 53 -j ACCEPT")
        if ip: os.system(f"iptables -A OUTPUT -d {ip} -j ACCEPT")
        
    def unlock(self):
        os.system("iptables -P OUTPUT ACCEPT; iptables -F OUTPUT")

class ExamCtrl:
    def __init__(self): self.active = False
    
    def _kill_browsers(self):
        # Force kill common browsers
        os.system("killall -9 chrome firefox brave microsoft-edge-stable 2>/dev/null")

    def enter(self):
        if self.active: return False
        save_state(True)
        self._kill_browsers()
        Firewall().lock()
        self.active = True
        trigger_sync("🚨 EXAM LOCKED", capture=True)
        return True

    def exit(self):
        if not self.active: return False
        save_state(False)
        Firewall().unlock()
        self.active = False
        trigger_sync("✅ EXAM UNLOCKED")
        return True

ctrl = ExamCtrl()

class USBWatch(threading.Thread):
    def __init__(self): super().__init__(daemon=True); self.mon = pyudev.Monitor.from_netlink(pyudev.Context()); self.mon.filter_by('usb')
    def run(self):
        for d in iter(self.mon.poll, None):
            if d.action == 'add' and ctrl.active:
                trigger_sync(f"⚠️ VIOLATION: USB Detected ({d.get('ID_MODEL','Device')})", capture=True)
                os.system("for d in /sys/bus/usb/devices/*; do echo 0 > $d/authorized 2>/dev/null; done")

class Heartbeat(threading.Thread):
    def __init__(self): super().__init__(daemon=True)
    def run(self):
        while True:
            time.sleep(60)
            if ctrl.active: ctrl._kill_browsers()

async def start(u, c): await u.message.reply_text(f"Connected to {HOSTNAME}")

async def exam(u, c): 
    # This runs in the Main Loop. calling ctrl.enter() calls trigger_sync().
    # trigger_sync() will now correctly use create_task() instead of crashing.
    if ctrl.enter():
        await u.message.reply_text("🔒 Locked.")
    else:
        await u.message.reply_text("⚠️ Already Locked.")

async def normal(u, c): 
    if ctrl.exit():
        await u.message.reply_text("✅ Unlocked.")
    else:
        await u.message.reply_text("ℹ️ Already Unlocked.")

async def post_init(application: Application):
    await send_alert("System Online")

def main():
    if not validate_license():
        print("FATAL: License Invalid or Expired.")
        sys.exit(1)
    
    atexit.register(lambda: (Firewall().unlock(), ctrl.exit()))
    USBWatch().start(); Heartbeat().start()
    
    if load_state():
        logging.warning("Recovered from crash. Re-locking system.")
        ctrl.enter()

    # We use post_init to safely send startup messages
    app = Application.builder().token(cfg.token).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("exam", exam))
    app.add_handler(CommandHandler("normal", normal))
    
    print(f"ExamShield v{VERSION} Running.")
    app.run_polling()

if __name__ == "__main__": main()