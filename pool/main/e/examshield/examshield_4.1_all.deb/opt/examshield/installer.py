#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox
import json, os, subprocess, requests

CFG="/etc/examshield/config.json"; LIC="/etc/examshield/license.key"; PROD_LINK="examshield"

def install():
    t=e1.get().strip(); c=e2.get().strip(); k=e3.get().strip()
    if not t or not c or not k: messagebox.showerror("Error","Missing Fields"); return
    
    # Online Verification
    try:
        r = requests.post("https://api.gumroad.com/v2/licenses/verify", 
                          data={"product_permalink": PROD_LINK, "license_key": k}, timeout=5)
        d = r.json()
        if not d.get("success") or d.get("purchase",{}).get("refunded"):
            messagebox.showerror("Error", "Invalid License Key"); return
    except: 
        pass # Offline fallback

    os.system("sudo mkdir -p /etc/examshield")
    with open(CFG,"w") as f: json.dump({"bot_token":t,"chat_id":c},f)
    os.chmod(CFG, 0o600)
    with open(LIC,"w") as f: f.write(k)
    
    # Auto-Fix Locks
    os.system("sudo rm -f /var/lib/dpkg/lock* /var/cache/apt/archives/lock >/dev/null 2>&1 || true")
    os.system("sudo dpkg --configure -a >/dev/null 2>&1 || true")
    
    # Install Deps
    subprocess.run("sudo apt update -y && sudo apt install -y python3-pip python3-tk python3-psutil python3-requests python3-mss gnome-screenshot iptables", shell=True)
    subprocess.run("sudo -H pip3 install --no-cache-dir pyudev python-telegram-bot psutil --break-system-packages", shell=True)
    
    svc="[Unit]\nDescription=ExamShield\nAfter=network.target\n[Service]\nUser=root\nEnvironment=DISPLAY=:0\nExecStart=/usr/bin/python3 /opt/examshield/examshield.py\nRestart=always\n[Install]\nWantedBy=multi-user.target"
    os.system(f"echo '{svc}' | sudo tee /etc/systemd/system/examshield.service > /dev/null")
    subprocess.run("sudo systemctl daemon-reload && sudo systemctl enable --now examshield.service", shell=True)
    messagebox.showinfo("Success", "Installed! Run 'examshield' to start."); root.destroy()

root=tk.Tk(); root.title("ExamShield Setup"); root.geometry("500x350")
ttk.Label(root,text="Bot Token:").pack(); e1=ttk.Entry(root,width=50); e1.pack()
ttk.Label(root,text="Chat ID:").pack(); e2=ttk.Entry(root,width=50); e2.pack()
ttk.Label(root,text="License Key:").pack(); e3=ttk.Entry(root,width=50); e3.pack()
ttk.Button(root,text="Install",command=install).pack(pady=20)
root.mainloop()
