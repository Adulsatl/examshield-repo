#!/usr/bin/env python3
"""
ExamShield v4.1 — Enterprise Exam Security System
Integrated with Gumroad Licensing (Expiry Logic) & Telemetry
"""
import os, sys, json, time, threading, socket, logging, psutil, asyncio, subprocess, atexit, requests, hashlib
from datetime import datetime

# --- CONFIGURATION ---
VERSION = "4.1" # FIXED: Updated to match Repo
# This permalink must match the end of your Gumroad URL (aduls.gumroad.com/l/examshield)
GUMROAD_PERMALINK = "examshield" 
CONFIG_FILE = '/etc/examshield/config.json'
LICENSE_FILE = '/etc/examshield/license.key'
CACHE_FILE = '/etc/examshield/.license_cache'
STATE_FILE = '/etc/examshield/state.json'
LOG_DIR = '/var/log/examshield'
HOSTNAME = socket.gethostname()
TELEGRAM_API_DOMAIN = "api.telegram.org"
TRUSTED_DNS = "8.8.8.8"

# Blacklists - Applications to kill during exam
BROWSERS = [
    '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable',
    '/usr/bin/chromium', '/usr/bin/chromium-browser',
    '/usr/bin/firefox', '/usr/bin/brave-browser', '/usr/bin/microsoft-edge'
]
DESKTOP_FILES = [
    '/usr/share/applications/google-chrome.desktop',
    '/usr/share/applications/chromium.desktop',
    '/usr/share/applications/firefox.desktop',
    '/usr/share/applications/brave-browser.desktop',
    '/usr/share/applications/microsoft-edge.desktop'
]

# Dependency Check
try:
    import pyudev, mss
    from telegram import Bot
    from telegram.ext import Application, CommandHandler
except ImportError:
    # Fail silently or log if running as service, dependencies should be installed by installer
    sys.exit(1)

# Logging Setup
os.makedirs(LOG_DIR, exist_ok=True)
logging.basicConfig(level=logging.INFO, filename=os.path.join(LOG_DIR, 'examshield.log'), format='%(asctime)s %(levelname)s: %(message)s')

# --- PERSISTENCE & CACHING ---
def save_state(active: bool):
    """Saves exam state to disk to survive reboots"""
    try:
        with open(STATE_FILE, 'w') as f: json.dump({"active": active}, f)
    except: pass

def load_state():
    """Loads exam state on startup"""
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, 'r') as f: return json.load(f).get("active", False)
    except: pass
    return False

def cache_license(key):
    """Caches valid license locally for offline support"""
    try:
        h = hashlib.sha256(f"{key}-{HOSTNAME}-valid".encode()).hexdigest()
        with open(CACHE_FILE, 'w') as f: json.dump({"valid": True, "hash": h, "date": time.time()}, f)
        os.chmod(CACHE_FILE, 0o600)
    except: pass

def check_cached_license(key):
    """Checks local cache if internet is down"""
    try:
        if not os.path.exists(CACHE_FILE): return False
        with open(CACHE_FILE, 'r') as f: data = json.load(f)
        h = hashlib.sha256(f"{key}-{HOSTNAME}-valid".encode()).hexdigest()
        # Valid for 24 hours offline
        if data.get("hash") == h and (time.time() - data.get("date", 0) < 86400):
            logging.info("License verified via Local Cache")
            return True
    except: pass
    return False

# --- LICENSE LOGIC ---
def validate_license():
    """Validates license key against Gumroad API with Expiry logic"""
    try:
        if not os.path.exists(LICENSE_FILE): return False
        with open(LICENSE_FILE, 'r') as f: key = f.read().strip()
        
        try:
            r = requests.post("https://api.gumroad.com/v2/licenses/verify", 
                              data={"product_permalink": GUMROAD_PERMALINK, "license_key": key}, timeout=5)
            data = r.json()
            
            if data.get("success") and not data.get("purchase", {}).get("refunded", False):
                variants = data.get("purchase", {}).get("variants", "")
                created = data.get("purchase", {}).get("created_at", "")
                
                # Expiry Calculation
                if created:
                    dt = datetime.fromisoformat(created.replace('Z', '+00:00'))
                    hours = (datetime.now(dt.tzinfo) - dt).total_seconds() / 3600
                    limit = 0
                    if "1 Month" in variants: limit = 720
                    elif "Semester" in variants: limit = 4320
                    elif "6 Months" in variants: limit = 4320
                    elif "1 Year" in variants: limit = 8760
                    
                    if limit > 0 and hours > limit: 
                        logging.critical("License Expired"); return False
                
                cache_license(key)
                return True
        except requests.exceptions.RequestException:
            logging.warning("Offline Mode: Checking Cache...")
            return check_cached_license(key)
            
    except Exception as e: logging.error(f"Lic Err: {e}")
    return False

# --- CORE CLASSES ---
class Config:
    def __init__(self):
        self.data = {}
        try:
            if (os.stat(CONFIG_FILE).st_mode & 0o777) != 0o600: os.chmod(CONFIG_FILE, 0o600)
            with open(CONFIG_FILE) as f: self.data = json.load(f)
        except: pass
    @property
    def token(self): return self.data.get('bot_token')
    @property
    def chat_id(self): return self.data.get('chat_id')
cfg = Config()

async def send_alert(msg, photo=None):
    if not cfg.token: return
    bot = Bot(token=cfg.token)
    try:
        if photo: await bot.send_photo(cfg.chat_id, photo=open(photo, 'rb'), caption=msg)
        else: await bot.send_message(cfg.chat_id, text=msg)
    except: pass

def trigger_sync(msg, capture=False):
    """Wrapper to call async alert from sync threads"""
    photo = None
    if capture:
        path = f"{LOG_DIR}/ev_{int(time.time())}.png"
        try:
            # Try MSS (Fastest)
            with mss.mss() as sct: sct.shot(mon=1, output=path); photo = path
        except:
            # Fallback for Wayland
            try: subprocess.run(["gnome-screenshot", "-f", path], timeout=2); photo = path if os.path.exists(path) else None
            except: pass
    try: asyncio.run(send_alert(f"🛡 {HOSTNAME}: {msg}", photo))
    except: pass

class Firewall:
    def lock(self):
        try: ip = socket.gethostbyname(TELEGRAM_API_DOMAIN)
        except: ip = None
        # Strict Output Policy: DROP everything by default
        cmds = [
            "iptables -F OUTPUT", "iptables -P OUTPUT DROP",
            "iptables -A OUTPUT -o lo -j ACCEPT",
            # Only allow Trusted DNS (8.8.8.8) to prevent tunneling
            f"iptables -A OUTPUT -p udp -d {TRUSTED_DNS} --dport 53 -j ACCEPT",
            f"iptables -A OUTPUT -p tcp -d {TRUSTED_DNS} --dport 53 -j ACCEPT"
        ]
        if ip: cmds.append(f"iptables -A OUTPUT -d {ip} -j ACCEPT")
        for c in cmds: os.system(c)
    def unlock(self):
        os.system("iptables -P OUTPUT ACCEPT; iptables -F OUTPUT")

class ExamCtrl:
    def __init__(self): self.active = False
    
    def _kill_browsers(self):
        for p in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                # Advanced matching: Checks binary name AND command line args (for renamed browsers)
                if any(x in (p.info['name'] or '').lower() for x in ('chrome', 'firefox', 'brave', 'edge')) \
                   or any(x in ' '.join(p.info['cmdline'] or []) for x in ('--type=renderer', 'content_shell')):
                    p.kill()
            except: pass

    def enter(self):
        if self.active: return False
        save_state(True)
        self._kill_browsers()
        # Chmod binaries to prevent restart
        for b in BROWSERS: 
            if os.path.exists(b): 
                try: st=os.stat(b); os.chmod(b, st.st_mode & ~0o111)
                except: pass
        Firewall().lock()
        self.active = True
        trigger_sync("🚨 EXAM LOCKED. Firewall Strict. Browsers Disabled.")
        return True

    def exit(self):
        if not self.active: return False
        save_state(False)
        Firewall().unlock()
        # Restore binaries
        for b in BROWSERS:
            if os.path.exists(b): os.chmod(b, 0o755)
        # Unblock USBs
        os.system("for d in /sys/bus/usb/devices/*; do echo 1 > $d/authorized 2>/dev/null; done")
        self.active = False
        trigger_sync("✅ EXAM UNLOCKED.")
        return True

ctrl = ExamCtrl()

class USBWatch(threading.Thread):
    def __init__(self): super().__init__(daemon=True); self.mon = pyudev.Monitor.from_netlink(pyudev.Context()); self.mon.filter_by('usb')
    def run(self):
        for d in iter(self.mon.poll, None):
            if d.action == 'add' and ctrl.active:
                trigger_sync(f"VIOLATION: USB {d.get('ID_MODEL','Device')}", capture=True)
                # Kernel level USB block
                os.system("for d in /sys/bus/usb/devices/*; do echo 0 > $d/authorized 2>/dev/null; done")

class Heartbeat(threading.Thread):
    def __init__(self): super().__init__(daemon=True)
    def run(self):
        while True:
            time.sleep(60)
            if ctrl.active: 
                ctrl._kill_browsers() # Re-enforce locks
                try: asyncio.run(send_alert("💓 Monitoring Active"))
                except: pass

async def start(u, c): await u.message.reply_text(f"Connected to {HOSTNAME}")
async def exam(u, c): await u.message.reply_text(f"Exam: {'Active' if ctrl.enter() else 'On'}")
async def normal(u, c): await u.message.reply_text(f"Normal: {'Restored' if ctrl.exit() else 'Off'}")

def main():
    if not validate_license():
        print("FATAL: License Invalid."); sys.exit(1)
    
    # Safety Net: Unlock on crash/exit
    atexit.register(lambda: (Firewall().unlock(), ctrl.exit()))
    USBWatch().start(); Heartbeat().start()
    
    # Reboot Persistence Check
    if load_state():
        logging.warning("Recovered from crash/reboot. Re-locking system.")
        ctrl.enter()

    app = Application.builder().token(cfg.token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("exam", exam))
    app.add_handler(CommandHandler("normal", normal))
    
    trigger_sync("System Online")
    app.run_polling()

if __name__ == "__main__": main()