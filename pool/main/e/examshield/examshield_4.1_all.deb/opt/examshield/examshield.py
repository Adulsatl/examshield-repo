#!/usr/bin/env python3
"""
ExamShield v4.1 — Enterprise Exam Security System
Integrated with Gumroad Licensing (Annual/Month/Lifetime)
"""
import os, sys, json, time, threading, socket, logging, psutil, asyncio, subprocess, atexit, requests, hashlib
from datetime import datetime, timedelta

# --- CONFIGURATION ---
VERSION = "4.1"

# ⚠️ GUMROAD CONFIGURATION ⚠️
GUMROAD_PERMALINK = "examshield" 

# File Paths
CONFIG_FILE = '/etc/examshield/config.json'
LICENSE_FILE = '/etc/examshield/license.key'
CACHE_FILE = '/etc/examshield/.license_cache'
STATE_FILE = '/etc/examshield/state.json'
LOG_DIR = '/var/log/examshield'
HOSTNAME = socket.gethostname()
TELEGRAM_API_DOMAIN = "api.telegram.org"
TRUSTED_DNS = "8.8.8.8"

# Blacklists
BROWSERS = [
    '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable',
    '/usr/bin/chromium', '/usr/bin/chromium-browser',
    '/usr/bin/firefox', '/usr/bin/brave-browser', '/usr/bin/microsoft-edge'
]

# Dependency Check
try:
    import pyudev, mss
    from telegram import Bot
    from telegram.ext import Application, CommandHandler
except ImportError:
    sys.exit(1)

# Logging
os.makedirs(LOG_DIR, exist_ok=True)
logging.basicConfig(level=logging.INFO, filename=os.path.join(LOG_DIR, 'examshield.log'), format='%(asctime)s %(levelname)s: %(message)s')

# --- PERSISTENCE ---
def save_state(active: bool):
    try:
        with open(STATE_FILE, 'w') as f: json.dump({"active": active}, f)
    except: pass

def load_state():
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, 'r') as f: return json.load(f).get("active", False)
    except: pass
    return False

def cache_license(key):
    try:
        h = hashlib.sha256(f"{key}-{HOSTNAME}-valid".encode()).hexdigest()
        with open(CACHE_FILE, 'w') as f: json.dump({"valid": True, "hash": h, "date": time.time()}, f)
        os.chmod(CACHE_FILE, 0o600)
    except: pass

def check_cached_license(key):
    try:
        if not os.path.exists(CACHE_FILE): return False
        with open(CACHE_FILE, 'r') as f: data = json.load(f)
        h = hashlib.sha256(f"{key}-{HOSTNAME}-valid".encode()).hexdigest()
        # Cache is valid for 24 hours (86400 seconds)
        if data.get("hash") == h and (time.time() - data.get("date", 0) < 86400):
            logging.info("License verified via Local Cache")
            return True
    except: pass
    return False

# --- LICENSE LOGIC (UPDATED FOR VARIANTS) ---
def validate_license():
    """Validates Annual, Month, and Lifetime variants"""
    try:
        if not os.path.exists(LICENSE_FILE): 
            print("License file missing.")
            return False
            
        with open(LICENSE_FILE, 'r') as f: key = f.read().strip()
        
        try:
            # 🟢 CHECK 1: Online Check
            r = requests.post("https://api.gumroad.com/v2/licenses/verify", 
                              data={"product_permalink": GUMROAD_PERMALINK, "license_key": key}, timeout=5)
            data = r.json()
            
            if data.get("success") and not data.get("purchase", {}).get("refunded", False):
                
                purchase = data.get("purchase", {})
                
                # Check for Subscription Cancellations (if you use recurring billing)
                if purchase.get("subscription_cancelled_at") or purchase.get("subscription_failed_at"):
                    logging.critical("Subscription Cancelled or Failed")
                    return False

                # Get Variant Name (Lowercase for easier matching)
                # Examples: "Tier: Annual", "Tier: Month", "Tier: Lifetime"
                variant = purchase.get("variants", "").lower()
                
                # 🟢 CHECK 2: Variant Logic
                
                # -- LIFETIME --
                if "lifetime" in variant:
                    # Valid forever
                    cache_license(key)
                    return True

                # -- DATE CALCULATION FOR TIME-LIMITED --
                created = purchase.get("created_at", "")
                if created:
                    # Convert Gumroad date to Python Object
                    dt_purchase = datetime.fromisoformat(created.replace('Z', '+00:00'))
                    dt_now = datetime.now(dt_purchase.tzinfo)
                    
                    # Calculate difference in days
                    days_active = (dt_now - dt_purchase).days
                    
                    # Check Limits
                    if "annual" in variant or "year" in variant:
                        if days_active > 366: # 1 Year + 1 Day Buffer
                            logging.critical("Annual License Expired")
                            return False
                            
                    elif "month" in variant:
                        if days_active > 32: # 31 Days + 1 Day Buffer
                            logging.critical("Monthly License Expired")
                            return False
                    
                    # If it matches no known variant, we assume valid if Gumroad said Success: True
                    # (This prevents valid purchases with typos in variant names from being blocked)
                
                cache_license(key)
                return True

        except requests.exceptions.RequestException:
            # 🟡 FALLBACK: Offline Check
            logging.warning("Offline Mode: Checking Cache...")
            return check_cached_license(key)
            
    except Exception as e: logging.error(f"Lic Err: {e}")
    return False

# --- CORE CLASSES ---
class Config:
    def __init__(self):
        self.data = {}
        try:
            if (os.stat(CONFIG_FILE).st_mode & 0o777) != 0o600: os.chmod(CONFIG_FILE, 0o600)
            with open(CONFIG_FILE) as f: self.data = json.load(f)
        except: pass
    @property
    def token(self): return self.data.get('bot_token')
    @property
    def chat_id(self): return self.data.get('chat_id')
cfg = Config()

async def send_alert(msg, photo=None):
    if not cfg.token: return
    bot = Bot(token=cfg.token)
    try:
        if photo: await bot.send_photo(cfg.chat_id, photo=open(photo, 'rb'), caption=msg)
        else: await bot.send_message(cfg.chat_id, text=msg)
    except: pass

def trigger_sync(msg, capture=False):
    photo = None
    if capture:
        path = f"{LOG_DIR}/ev_{int(time.time())}.png"
        try:
            with mss.mss() as sct: sct.shot(mon=1, output=path); photo = path
        except:
            try: subprocess.run(["gnome-screenshot", "-f", path], timeout=2); photo = path if os.path.exists(path) else None
            except: pass
    try: asyncio.run(send_alert(f"🛡 {HOSTNAME}: {msg}", photo))
    except: pass

class Firewall:
    def lock(self):
        try: ip = socket.gethostbyname(TELEGRAM_API_DOMAIN)
        except: ip = None
        cmds = [
            "iptables -F OUTPUT", "iptables -P OUTPUT DROP",
            "iptables -A OUTPUT -o lo -j ACCEPT",
            f"iptables -A OUTPUT -p udp -d {TRUSTED_DNS} --dport 53 -j ACCEPT",
            f"iptables -A OUTPUT -p tcp -d {TRUSTED_DNS} --dport 53 -j ACCEPT"
        ]
        if ip: cmds.append(f"iptables -A OUTPUT -d {ip} -j ACCEPT")
        for c in cmds: os.system(c)
    def unlock(self):
        os.system("iptables -P OUTPUT ACCEPT; iptables -F OUTPUT")

class ExamCtrl:
    def __init__(self): self.active = False
    
    def _kill_browsers(self):
        for p in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                if any(x in (p.info['name'] or '').lower() for x in ('chrome', 'firefox', 'brave', 'edge')):
                    p.kill()
            except: pass

    def enter(self):
        if self.active: return False
        save_state(True)
        self._kill_browsers()
        Firewall().lock()
        self.active = True
        trigger_sync("🚨 EXAM LOCKED.")
        return True

    def exit(self):
        if not self.active: return False
        save_state(False)
        Firewall().unlock()
        self.active = False
        trigger_sync("✅ EXAM UNLOCKED.")
        return True

ctrl = ExamCtrl()

class USBWatch(threading.Thread):
    def __init__(self): super().__init__(daemon=True); self.mon = pyudev.Monitor.from_netlink(pyudev.Context()); self.mon.filter_by('usb')
    def run(self):
        for d in iter(self.mon.poll, None):
            if d.action == 'add' and ctrl.active:
                trigger_sync(f"VIOLATION: USB {d.get('ID_MODEL','Device')}", capture=True)
                os.system("for d in /sys/bus/usb/devices/*; do echo 0 > $d/authorized 2>/dev/null; done")

class Heartbeat(threading.Thread):
    def __init__(self): super().__init__(daemon=True)
    def run(self):
        while True:
            time.sleep(60)
            if ctrl.active: 
                ctrl._kill_browsers()
                try: asyncio.run(send_alert("💓 Monitoring Active"))
                except: pass

async def start(u, c): await u.message.reply_text(f"Connected to {HOSTNAME}")
async def exam(u, c): await u.message.reply_text(f"Exam: {'Active' if ctrl.enter() else 'On'}")
async def normal(u, c): await u.message.reply_text(f"Normal: {'Restored' if ctrl.exit() else 'Off'}")

def main():
    if not validate_license():
        print("FATAL: License Invalid or Expired.")
        sys.exit(1)
    
    atexit.register(lambda: (Firewall().unlock(), ctrl.exit()))
    USBWatch().start(); Heartbeat().start()
    
    if load_state():
        logging.warning("Recovered from crash/reboot. Re-locking system.")
        ctrl.enter()

    app = Application.builder().token(cfg.token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("exam", exam))
    app.add_handler(CommandHandler("normal", normal))
    
    trigger_sync("System Online")
    app.run_polling()

if __name__ == "__main__": main()