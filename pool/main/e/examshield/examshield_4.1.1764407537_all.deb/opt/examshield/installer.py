#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox
import json, os, subprocess, sys

CFG="/etc/examshield/config.json"
LIC="/etc/examshield/license.key"
PROD_ID="Jq1p0Sw3o7xP0UGGTy38WQ=="

def install():
    t=e1.get().strip()
    c=e2.get().strip()
    k=e3.get().strip()
    
    if not t or not c or not k: 
        messagebox.showerror("Error","Missing Fields")
        return
    
    print(f"Verifying Key for Product ID: {PROD_ID}")

    # 🟢 GUMROAD VERIFICATION
    try:
        cmd = [
            "curl", "-s", "-X", "POST",
            "https://api.gumroad.com/v2/licenses/verify",
            "-d", f"product_id={PROD_ID}",
            "-d", f"license_key={k}",
            "-d", "increment_uses_count=false"
        ]
        
        result = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
        d = json.loads(result)
        
        print(f"Gumroad Response: {d}") 

        if not d.get("success") or d.get("purchase",{}).get("refunded"):
            msg = d.get("message", "Unknown Error")
            if "product_id" in msg: msg = "ID Mismatch."
            messagebox.showerror("Verification Failed", f"License Rejected.\nReason: {msg}"); 
            return
        
        print("License Validated.")

    except Exception as e:
        messagebox.showerror("Error", f"Validation Error: {e}")
        return

    # Save Credentials
    os.system("sudo mkdir -p /etc/examshield")
    with open(CFG,"w") as f: json.dump({"bot_token":t,"chat_id":c},f)
    os.chmod(CFG, 0o600)
    with open(LIC,"w") as f: f.write(k)
    
    # Install Python Libs
    # We use pip because 'apt' cannot be used here (recursive lock)
    # We check if they are already installed to save time
    print("Installing Python libraries...")
    try:
        subprocess.run("sudo -H pip3 install --no-cache-dir pyudev python-telegram-bot psutil mss --break-system-packages", shell=True, check=True)
    except:
        print("Warning: pip install encountered issues, but continuing.")

    # Create Service
    svc="[Unit]\nDescription=ExamShield\nAfter=network.target\n[Service]\nUser=root\nEnvironment=DISPLAY=:0\nExecStart=/usr/bin/python3 /opt/examshield/examshield.py\nRestart=always\n[Install]\nWantedBy=multi-user.target"
    os.system(f"echo '{svc}' | sudo tee /etc/systemd/system/examshield.service > /dev/null")
    subprocess.run("sudo systemctl daemon-reload && sudo systemctl enable --now examshield.service", shell=True)
    
    # 🟢 CRITICAL FIX: Use quit() instead of destroy()
    messagebox.showinfo("Success", "Installed! Run 'examshield' to start.")
    root.quit()

root=tk.Tk(); root.title("ExamShield Setup"); root.geometry("500x350")
ttk.Label(root,text="Bot Token:").pack(pady=5); e1=ttk.Entry(root,width=50); e1.pack()
ttk.Label(root,text="Chat ID:").pack(pady=5); e2=ttk.Entry(root,width=50); e2.pack()
ttk.Label(root,text="License Key:").pack(pady=5); e3=ttk.Entry(root,width=50); e3.pack()
ttk.Button(root,text="Install & Verify",command=install).pack(pady=20)
root.mainloop()
